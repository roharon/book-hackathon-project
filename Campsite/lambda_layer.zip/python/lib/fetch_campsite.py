from os import environ
import json

from time import sleep
import requests

URL = "http://apis.data.go.kr/B551011/GoCamping/basedList"


def fetch_campsite():
	params = {
		"pageNo": "1",
		"numOfRows": "100",
		"MobileOS": "ETC",
		"MobileApp": "AppTest",
		"serviceKey": environ['service_key'],
		"_type": "json"
	}

	response = requests.get(URL, params=params, verify=False)
	campsites = json.loads(response.text)['response']['body']['items']['item']

	return campsites
